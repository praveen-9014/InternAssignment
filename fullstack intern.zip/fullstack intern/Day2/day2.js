// const sayHello = ()=>{
//     setTimeout(()=>{
//         console.log("hello");
//     }, 5000);
// }

// const sayBye = ()=>{
//     console.log("bye");
// }

// sayHello();
// sayBye();

// const interval = setInterval(() => {
//     console.log("vanakam");
// }, 2000);

// clearInterval(interval);

// const myPromise = new Promise((resolve, reject) => {
//     const success = true; 
  
//     if (success) {
//       resolve("Promise resolved successfully!");
//     } else {
//       reject("Promise rejected with an error!");
//     }
//   });
  
//async and await
// const data = ()=>{
//     const response = fetch('https://jsonplaceholder.typicode.com/todos/1')
//     return response;
// }

// console.log(data());

// data().then((data) => {
//     console.log(data);
//     console.log(data.json);
// }).catch((err) => {
//     console.log(err);
// });
  
// const data = async()=>{
//     let response = await fetch('https://jsonplaceholder.typicode.com/todos/1');
//     response = await response.json();
//     console.log(response);
// }

// data();

// DOM and BOM
// let h1 = document.getElementById("d2");
// console.log(h1);

// h1.innerHTML = "Minato Namikaze"

// let div = document.createElement("div");
// div.innerText = "create using js";
// console.log(div);

// let div = document.createElement("div");

// let body = document.getElementById("data");
// let ul = document.createElement("ul");
// let li1 = document.createElement("li");
// let li2 = document.createElement("li");
// let li3 = document.createElement("li");
// let li4 = document.createElement("li");
// let li5 = document.createElement("li");
// let li6 = document.createElement("li6");

// ul.append(li1,li2,li3,li4,li5,li6);
// console.log(ul);

// let text1 = document.createTextNode("onion");
// let text2 = document.createTextNode("orange");
// let text3 = document.createTextNode("sugar");
// let text4 = document.createTextNode("potato");
// let text5 = document.createTextNode("padma");

// let text6 = document.createTextNode("crab");

// li1.append(text1);
// li2.append(text2);
// li3.append(text3);
// li4.append(text4);
// li5.append(text5);


// li6.append(text6);

// console.log(ul);
// body.append(ul);

// ul.setAttribute("id", "tag");

// // ul.style.backgroundColor = "red";
// ul.style.cssText = `color:teal`;

// let fruits = ['apple', 'mango', 'orange'];

// let ul = document.createElement("ul");

// fruits.map((i) =>{
//     let li = document.createElement("li");
//     let tn = document.createTextNode(i);
//     li.append(tn)
//     ul.append(li)
// })

// body.append(ul);

// // the method name is prepared

// // body.children[0].remove();

// // let li = document.getElementById("one");
// // li.remove();

// let date = new Date();
// console.log(date.getDate());
// console.log(date.getHours());
// console.log(date.getMinutes());
// console.log(date.getSeconds());

// exceptional handling in javaScript

// try{
//     let a = 10;
//     let b = 10;
//     if(b == 0){
//         throw "Zero division error";
//     }
//     let c = a/b;
//     console.log(c);
// }
// catch(err){
//     console.log(err)
// }
// finally{
//     console.log("End of Try and Catch");
// }

// let button = document.getElementById('button');

// button.addEventListener("dblclick", ()=>{
//     alert("vanakam");
// })

// let click = document.getElementsByClassName('div1')[0];

// click.addEventListener("click", ()=>{
//     alert("parent");
// })

// let child1 = document.getElementsByClassName('div2')[0];

// click.addEventListener("click", ()=>{
//     alert("child1");
// })

// let child2 = document.getElementsByClassName('div3')[0];

// click.addEventListener("click", (e)=>{
//     e.stopPropagation();
//     alert("child2");
// })

// // const remove = ()=>{
// //     child2.removeEventListener("click");
// // }

// const event1 = (e)=>{
//     alert("you clicked the child2");

//     remove();
// }

// child2.addEventListener("click", event1)
// const remove = ()=>{
//     child2.removeEventListener("click",event1);
// }

// let practice = document.getElementById("practice");

// practice.addEventListener("click",()=>{
//     alert("Click event");
// })


// practice.addEventListener("dblclick",()=>{
//     alert("double click event");
// })

// practice.addEventListener("mouseover",()=>{
//     alert("mouseup event");
// })

// practice.addEventListener("mouseout",()=>{
//     alert("mouseout event");
// })

// const catchKeyBoard = (e)=>{
//     console.log(e.key);
// }

// window.addEventListener("keydown", catchKeyBoard);

// const counterElement = document.querySelector('.counter');
//         const decrementButton = document.getElementById('decrement');
//         const incrementButton = document.getElementById('increment');

//         let count = 0;

//         decrementButton.addEventListener('click', () => {
//             count--;
//             counterElement.textContent = count;
//         });

//         incrementButton.addEventListener('click', () => {
//             count++;
//             counterElement.textContent = count;
//         });

function fibonacci(n) {
    const cache = [];  
    function fib(n) {
      if (n <= 1) return n;
      if (cache[n] !== undefined) return cache[n]; 

      cache[n] = fib(n - 1) + fib(n - 2); 
      return cache[n];
    }
    return fib(n);
  }
  console.log(fibonacci(50)); 

