const { Schema, model } = require('mongoose');
const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
    name:{
        type:String,
        required: true,
    },
    email:{
        type:String,
        require:true,
        minLength:10,
        maxLength:20,
        lowercase:true
    },
    age:{
        type:Number,
        required:true,
        min:18,
        max:70
    },
    friend: {
        type: Schema.Types.ObjectId,
        ref: "customer",            
    },
    address:{
        state:String,
        pincode:Number
    },
    hobbies:[String]
})


const customer = model('Customer', customerSchema);

module.exports = customer;