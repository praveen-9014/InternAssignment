const express = require('express');
const mongoose = require('mongoose');
const cust = require("./schema")
const app = express();
const port = 3000;

const db = async ()=>{
    try{
        await mongoose.connect('mongodb://localhost:27017/customer');
        console.log("mongoDB is connected");
    }
    catch(err){
        console.log("not connected");
    }

    const newCustomer = await cust.create({
        name:'jack',
        email:"Praveen9014@gmai.com",
        friend:"67986222fdf4b27df7348769",
        age:19,
        address:{
            state:"tamilnadu",
            pincode:12345,
        },
        hobbies:["gaming", "reading"]
    }).catch((err)=> console.log("error"))

    // console.log(newCustomer)

    // const customerData = await cust.findById("67986222fdf4b27df7348769",{name:1,age:1, _id:0});
    // console.log(customerData);

    // const customerData1 = await cust.find().where("name").equals("jack");
    // console.log(customerData1);

        // const customerData1 = await cust.findById("67986222fdf4b27df7348769").populate("friend");
        // console.log(customerData1);

        const updatedData = await cust.updateOne({ name: "jack" }, { $set: { age: 30 } });
        console.log(updatedData);

        // const customerData = await cust.findById("67986222fdf4b27df7348769");
        // console.log(customerData);
        
    }
    

db();

    

// const newCustomer = new cust({
//     name:'jack',
//     age:19,
//     address:{
//         state:"tamilnadu",
//         pincode:12345,
//     },
//     hobbies:["gaming", "reading"]
// })

// newCustomer.save();

app.listen(port, ()=>{
    console.log(`The server is running on port ${port}`);
})
