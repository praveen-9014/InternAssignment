import React, { useState } from 'react'
import axios from 'axios';
import Views from './Views';

const Search = () => {
    
    const [value, setValue] = useState("");
    const [data, setData] = useState([]);

    const handleViews = async()=>{
        const res = await axios.get(`http://localhost:3000/api/v1/search?search=${value}`);
        setData(res.data);
        console.log(data);
    }


    const handleSubmit = async(e)=>{
        e.preventDefault();
        handleViews();

    }

  return (
    <>
        <form action="">
            <input 
                type="text"
                value={value}
                onChange={(e)=>setValue(e.target.value)}
            />
            <button onClick={handleSubmit}>search</button>
        </form>

        {
            data.map((item) =>{
                <Views
                    title={item.title}
                    description={item.description}
                />
            })
        }
    </>
  )
}

export default Search