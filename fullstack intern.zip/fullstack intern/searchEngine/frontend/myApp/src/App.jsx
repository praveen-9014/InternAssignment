import React from 'react'
import Search from './Search'
import Views from './Views'

const App = () => {
  return (
    <>
      <Search />
      <view />
    </>
  )
}

export default App