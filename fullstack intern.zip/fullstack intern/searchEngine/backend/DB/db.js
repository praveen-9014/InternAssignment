const mongoose = require('mongoose');

const dbConnectivity = async()=>{
    try{
        await mongoose.connect('mongodb://localhost:27017/course')
        console.log("DB connected");
    }
    catch(err){
        console.log("DB id not connected");
    }
}

dbConnectivity();

module.exports = dbConnectivity;

