const {Schema, model } = require('mongoose');

const cousreDetails = new Schema({
    title:String,
    description:String
})

const data = model('coursedetails', cousreDetails);

module.exports = data;