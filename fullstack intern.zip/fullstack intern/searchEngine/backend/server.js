const express = require('express');
const mongoose = require('mongoose');
const cors = require("cors");
const db = require('./DB/db')
const courseSchema = require('./models/schema')
const app = express();
const port = 3000;

app.use(cors());

app.get('/api/v1/search', async(req, res)=>{
    await db();

    let query  = req.query.search;

    const course = await courseSchema.find({title:{$regex:query, $options:'i'}});
    res.json(course);
})

app.listen(port, ()=>{
    console.log(`The port is running on ${port}`);
    
})