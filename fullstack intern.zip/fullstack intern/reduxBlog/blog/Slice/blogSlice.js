import { createSlice } from '@reduxjs/toolkit';

const initialState = [
  { id: 1, author: "Minato", data: "yellow flash of the hidden leaf" },
  { id: 2, author: "Naruto", data: "seventh hokage" },
  { id: 3, author: "Sasuke", data: "shadow hokage" },
];

const blogSlice = createSlice({
  name: 'blogs',
  initialState,
  reducers: {
    addPost: (state, action) => {
      const newPost = {
        id: state.length + 1, 
        ...action.payload, 
      };
      state.push(newPost);
    },
  },
});

export const { addPost } = blogSlice.actions;
export default blogSlice.reducer;
