import React from 'react'
import { Link } from 'react-router-dom'

const Navigation = () => {
  return (
    <nav>
        <div><h1 className='.blog-section'>Blog</h1></div>
        <ul>
            <li><Link to={"/viewpost"}>ViewPost</Link></li>
            <li><Link to={"/addpost"}>AddPost</Link></li>
        </ul>
    </nav>
  )
}

export default Navigation