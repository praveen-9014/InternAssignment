import React from 'react'
import { Route,Routes,Link } from 'react-router-dom'
import AddPost from './AddPost'
import ViewPost from './ViewPost'
import Navigation from './Navigation'
import './App.css';



const App = () => {
  return (
    <>
      <Navigation/>
      <Routes>
        <Route path='/addpost' element={<AddPost/>} />
        <Route path='/viewpost' element={<ViewPost/>} />
      </Routes>
    </>
  )
}

export default App