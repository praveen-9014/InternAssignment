import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addPost } from '../Slice/blogSlice';

const AddPost = () => {
  const [author, setAuthor] = useState('');
  const [data, setData] = useState('');
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (author.trim() && data.trim()) {
      dispatch(addPost({ author, data })); 
      setAuthor(''); 
      setData('');
    } else {
      alert('Please fill out both fields.');
    }
  };

  return (
    <div className='AddPostContainer main'>
      <label htmlFor="author">Author</label>
      <input
        type="text"
        value={author}
        onChange={(e) => setAuthor(e.target.value)} 
      />

      <label htmlFor="data">Content</label>
      <input
        type="text"
        value={data}
        onChange={(e) => setData(e.target.value)}
      />

      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
};

export default AddPost;
