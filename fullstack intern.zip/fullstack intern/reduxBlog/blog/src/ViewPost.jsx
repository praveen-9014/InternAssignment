import React from 'react';
import { useSelector } from 'react-redux';

const ViewPosts = () => {
  const blogs = useSelector((state) => state.blogs); 
  console.log(blogs);

  return (
    <>
      <ul className="ViewPostContainer">
        {blogs.map((blog) => (
          <li key={blog.id}>
            <strong><strong style={{color:'#750CF5FF' }}>{blog.id}</strong> {blog.author}:</strong> <p style={{paddingLeft:"30px", fontWeight:"500px"}} >{blog.data}</p>
          </li>
        ))}
      </ul>
    </>
  );
};

export default ViewPosts;
