const express = require('express');
const DB = require('./DB/db')
const app = express();
const cors = require('cors')
const todoSchema = require("./model/schema")

app.use(cors());
app.use(express.json());
app.get('/api/v1/todo', async(req, res)=>{
    await DB();
    const task = await todoSchema.find();
    res.json(task);
})

app.put('/api/v1/todo/:id', async(req, res)=>{
    let id = req.params.id;
    const response = await todoSchema.updateOne({_id:id},{$set:{task:req.body.task}})
    res.json(response)
})

app.patch('/api/v1/todo', async(req, res)=>{

})

app.post('/api/v1/todo', async(req, res)=>{
    await DB();
    const body = await req.body;
    const status = await todoSchema.create(body);
    res.json(status);
})

app.delete('/api/v1/todo/:id', async(req, res)=>{
    let id = req.params.id;
    const response = await todoSchema.deleteOne({_id:id})
    res.json(response)
})

app.listen(3000,()=>{
    console.log("server is running");
})