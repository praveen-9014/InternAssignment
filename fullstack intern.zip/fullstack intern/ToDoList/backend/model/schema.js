const {Schema, model} = require("mongoose");

const data = new Schema({
    task:String
})

module.exports = model("task", data);