import React from 'react'
import Taskview from './Taskview'
import AddTask from './AddTask'

const App = () => {
  return (
    <>
      <AddTask/>
    </>
  )
}

export default App