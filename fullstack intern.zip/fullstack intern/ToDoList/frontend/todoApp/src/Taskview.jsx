import React, { useState } from "react";
import axios from "axios";

const Taskview = ({ task, id, onDelete, onUpdate }) => {
  const [editMode, setEditMode] = useState(false);
  const [updatedTask, setUpdatedTask] = useState(task);

  const handleDelete = async () => {
    try {
      await axios.delete(`http://localhost:3000/api/v1/todo/${id}`);
      console.log(`Deleted task with ID: ${id}`);
      onDelete(id);
    } catch (error) {
      console.error("Error deleting task:", error);
    }
  };


  const handleUpdate = async () => {
    try {
      const res = await axios.put(`http://localhost:3000/api/v1/todo/${id}`, {
        task: updatedTask,
      });
      console.log("Task updated:", res.data);
      setEditMode(false);
      onUpdate(id, updatedTask);
    } catch (error) {
      console.error("Error updating task:", error);
    }
  };

  return (
    <div>
      <p>{id}</p>
      {editMode ? (
        <input
          type="text"
          value={updatedTask}
          onChange={(e) => setUpdatedTask(e.target.value)}
        />
      ) : (
        <p>{task}</p>
      )}

      {editMode ? (
        <button onClick={handleUpdate}>Save</button>
      ) : (
        <button onClick={() => setEditMode(true)}>Edit</button>
      )}

      <button onClick={handleDelete}>Delete</button>
    </div>
  );
};

export default Taskview;
