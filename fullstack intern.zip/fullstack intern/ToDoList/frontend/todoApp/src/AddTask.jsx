import React, { useEffect, useState } from "react";
import Taskview from "./Taskview";
import axios from "axios";

const AddTask = () => {
  const [value, setValue] = useState("");
  const [data, setData] = useState([]);

  useEffect(() => {
    const getData = async () => {
      try {
        const res = await axios.get("http://localhost:3000/api/v1/todo");
        setData(res.data);
      } catch (error) {
        console.error("Error fetching tasks:", error);
      }
    };

    getData();
  }, []);

  const handleClick = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3000/api/v1/todo", {
        task: value,
      });
      setData([...data, res.data]);
      setValue(""); 
    } catch (error) {
      console.error("Error adding task:", error);
    }
  };

  const handleDelete = (id) => {
    setData(data.filter((task) => task._id !== id));
  };

  const handleUpdate = (id, updatedTask) => {
    setData(data.map((task) => (task._id === id ? { ...task, task: updatedTask } : task)));
  };

  return (
    <>
      <form>
        <input 
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
        <button onClick={(e) => handleClick(e)}>Submit</button>
      </form>

      {data.length > 0 &&
        data.map((item) => (
          <Taskview
            key={item._id}
            id={item._id}
            task={item.task}
            onDelete={handleDelete}
            onUpdate={handleUpdate}
          />
        ))}
    </>
  );
};

export default AddTask;
