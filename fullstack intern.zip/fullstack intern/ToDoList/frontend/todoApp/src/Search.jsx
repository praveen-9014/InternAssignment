import React from 'react'

const Search = () => {
  return (
    <>
        <form action="">
            <input type="text" />
            <button>submit</button>
        </form>
    </>
  )
}

export default Search