const express = require('express');
const app = express();
const port = 3000;
const {engine} = require('express-handlebars')
const path = require('path');

app.set('view engine', 'hbs');
app.engine("hbs", engine({ extname:"hbs", defaultLayout:false }))

app.use(express.static(path.join(__dirname, './public')));

app.get('/index.html', (req, res) => {
    let data = "minato Namikaze";
    let arr = [1,2,3,4,5];
    res.render("home", {data, arr});
});

app.get('/home', (req, res)=>{
    let data = "minato Namikaze";
    let arr = [1,2,3,4,5];
    res.render("home", {data, arr});
})

app.get('/about', (req, res) => {
    let arr = [1,2,3,4,5];
    res.render("about", {arr});
});

app.get('/contact', (req, res) => {
    res.render("contact");
});

app.listen(port, ()=>{
    console.log(`The server is running on ${port}`);
})