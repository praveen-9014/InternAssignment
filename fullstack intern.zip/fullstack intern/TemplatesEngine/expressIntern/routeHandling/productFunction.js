const fs = require('fs');
const path = require('path');
const jsonData = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "models", 'product.json'), 'utf-8'))

const idValidator = (req, res, next, value)=>{
    const id = value*1;
    const item = jsonData.find((item)=> item.id === value);
    if(!item){
        return res.status(400).json({
            status:'fail',
            message:'No Product Found'
        })
    }

    next();
}

const validate = (req, res, next)=>{
    const item = req.body;
    const header = req.headers
    console.log(header);
    if(header.token !== "pass"){
        return res.status(400).json({
            status:'fail',
            message:'unauth access'
        })
    }

    if(!item.name || !item.count){
        return res.json({
            status:'fail',
            message:'bad request'
        })
    }
    next();
}

const getWithoutID = (req, res)=>{
    try{
        res.status(200).json({
            status:"fulfilled",
            count:jsonData.length,
            data:{
                products:jsonData
            }
        })
    }
    catch(err){
        res.status(500).json({
            status:"fail",
            message:err
        });
    }
}

const getWithId = (req, res)=>{
    try {
        console.log(req.params.id);
        const {productId} = req.params.id;
        const product = jsonData.find((item) => item.id === parseInt(productId)); 

        
        if (product) {
            res.status(200).json({
                status: "fulfilled",
                data: {
                    product: product
                }
            });
        } else {
            res.status(404).json({
                status: "fail",
                message: "Product not found"
            });
        }
    } catch (err) {
        res.status(500).json({
            status: "fail",
            message: err.message
        });
    }
}

const postOption = (req, res)=>{
    const id = jsonData.length + 1;
    const newProduct = {id:id, ...req.body};
    jsonData.push(newProduct);

    fs.writeFileSync(path.join(__dirname, "..", "models", 'product.json'), JSON.stringify(jsonData))

    res.status(200).json({
        status:"fulfilled",
        count:jsonData.length,
        data:{
            products:jsonData
        }
    })
}

const deleteOption = (req, res)=>{
    let id = req.params.id*1;
    let deletedJson = jsonData.filter((prod)=>prod.id !== id);

    fs.writeFile(path.join(__dirname, "..", "models", 'product.json'), JSON.stringify(deletedJson),()=>{})
    res.status(204)
    res.json();
}

const patchOption = (req, res)=>{
    let id = req.params.id*1;
    let updateProd = jsonData.find((prod)=> prod.id === id);
    let index = jsonData.indexOf(updateProd);

    console.log(jsonData[index]);
    jsonData[index] = Object.assign(updateProd, req.body);
    fs.writeFile(path.join(__dirname, "..", "models", 'product.json'), JSON.stringify(jsonData),()=>{})

    res.status(204).json({
        status:"fulfilled",
        count:jsonData.length,
        data:{
            products:jsonData
        }
    })
}

const putOption = (req, res)=>{
    let id = req.params.id*1;
    let updateProd = jsonData.find((prod)=> prod.id === id);
    let index = jsonData.indexOf(updateProd);

    console.log(jsonData[index]);
    jsonData[index] = (req.body)
    fs.writeFile(path.join(__dirname, "..", "models", 'product.json'), JSON.stringify(jsonData),()=>{})

    res.status(201);
    res.json({
        status:"completed",
    })
}

module.exports = {getWithId, getWithoutID, postOption, deleteOption, putOption, patchOption, validate, idValidator}
