const express = require('express')
const app = express();
const productRoutes = express.Router()
const {getWithId, getWithoutID, deleteOption, putOption, patchOption, postOption, validate, idValidator} = require('../routeHandling/productFunction');

// productRoutes.param("id", (req, res, next, value)=>{
//     console.log("id", value);
//     next();
// })

dotenv.config({path:""})

productRoutes.param("id", idValidator);
productRoutes.route("/").get(getWithoutID).post(validate,postOption);
productRoutes.route("/:id").get(getWithId).delete(deleteOption).patch(patchOption).put(putOption);

module.exports = productRoutes