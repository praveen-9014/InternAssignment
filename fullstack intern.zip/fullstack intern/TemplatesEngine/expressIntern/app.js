const express = require('express');
const morgan = require('morgan');
const app = express();
const productRoutes = require('./routes/productsRoute');
const dotenv = require('dotenv')
dotenv.config({path:"./config.env"})
const port = 3000;

// const fun = ()=>{
//     console.log("odnvfjn");
// }

// app.use((req, res, next) => {
//     next()
// })

// console.log("outside")

app.use(express.json())
app.use(morgan("dev"));

//binding the url
app.use("/api/v1/products",productRoutes)



module.exports = {app, port};