let game = confirm("Do you want to play Rock, Paper, Scissors?");
if (game) {
    let ingame = confirm("The game is Rock, Paper, and Scissors. Ready?");
    if (ingame) {
        while (true) {
            let player = prompt("Enter Rock, Paper, or Scissors:");
            if (player) {
                let playerChoice = player.trim().toLowerCase();

                if (["rock", "paper", "scissors"].includes(playerChoice)) {
                    const choices = ["rock", "paper", "scissors"];
                    let computerChoice = choices[Math.floor(Math.random() * 3)];

                    alert(`You chose: ${playerChoice}\nComputer chose: ${computerChoice}`);

                    let result = playerChoice === computerChoice
                        ? "It's a tie!"
                        : (playerChoice === "rock" && computerChoice === "scissors") ||
                          (playerChoice === "paper" && computerChoice === "rock") ||
                          (playerChoice === "scissors" && computerChoice === "paper")
                        ? "You win!"
                        : "Computer wins!";

                    alert(result);

                    let playAgain = confirm("Do you want to play again?");
                    playAgain ? null : alert("Thanks for playing!");
                    if (!playAgain) break;
                } else {
                    alert("Invalid choice");
                }
            } else {
                alert("You didn't enter anything");
                break;
            }
        }
    } else {
        alert("Okay! Maybe next time.");
    }
} else {
    alert("Goodbye! See you next time.");
}
