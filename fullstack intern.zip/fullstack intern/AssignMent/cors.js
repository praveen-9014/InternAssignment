const express = require("express");
const app = express();
const path = require('path')
const PORT = 5000;

const cors = require('cors');

app.use(cors({
    origin:'https://www.google.co.in/'
})
)

app.get('/',(req,res) =>{
    console.log("process");
    res.send("ore wa namikaze minato");
    res.json({name:'praveen'})
})

app.listen(PORT,() =>{
    console.log(`port is running on ${PORT}`)
})