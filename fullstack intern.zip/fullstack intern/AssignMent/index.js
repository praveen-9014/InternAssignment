var a = 10;
var b = 20;
console.log(a + b);

// string
var a = "  Minato Namikaze";
console.log(a);
console.log(a.length);
console.log(a.split(" "));
console.log(a.trim());
console.log(a.charAt(5));
console.log(a.indexOf('a'));
console.log(a.lastIndexOf('a'));
console.log(`my name is ${a}`);

// number
var num = 123.4;
console.log(num)

// math
var intvalue = 123.6;
console.log(Math.round(intvalue));
console.log(Math.ceil(intvalue));
console.log(Math.floor(intvalue));
console.log(Math.pow(2,3));
console.log(Math.floor(Math.random()*10)-1);

var negative = -100;
var n = 8;
console.log(Math.abs(negative));
console.log(Math.sqrt(n));
console.log(Math.cbrt(n));

var booleanVar = false;
console.log(booleanVar);

//undefined
var dataType
console.log(dataType);

// null
var DType = null;
console.log(DType);

// arrays

var arr = [1, 2, 3, "Minato", false, 'a'];
console.log(arr);
console.log(arr[0]);

arr.push(100);
console.log(arr);

arr.pop();
console.log(arr);

var arrayVariable = [5, 1, "str", {obj:1}];
arrayVariable.shift();
console.log(arrayVariable);

// assignment
var str = "minato";
str = str.split("");


//for loop
for(var i=5;i>0;i--){
    console.log(i)
}

var i = 0;
while(true){
    if(i == 5){
        break;
    }
    console.log(i++);
}

// do while

console.log("do while");
var i=1;
do{
    console.log(i);
}while(false)

// higher order function

["apple", "mango", "grapes"].forEach(
    i=>{
        console.log(i);
    }
)

var item = ["apple", "mango", "grapes"].forEach(
    (i,k)=>{
        console.log(i,k);
    }
)

var ch = 'a';
if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'){
    console.log("Yes");
} 
else{
    console.log("NO");
}

var ch = 'a';
switch(ch){
    case 'a':
        console.log("Yes");
        break;
    case 'e':
        console.log("Yes");
        break;
    case 'i':
        console.log("Yes");
        break;
    case 'o':
        console.log("Yes");
        break;
    case 'u':
        console.log("Yes");
        break;
    default:
        console.log("NO");
        break;
}

// ternary operator
var sampleVar = sampleVar=='a'?true:false;

console.log(eval(5*3-2));
console.log(5*3-2);

// function
// function is a block of code
console.log("function tutorial");
var sayHello = (a, b) => a*b

for(var i=0;i<10;i++){
    console.log(sayHello(i,i+1));
}

//class
var check = 10;

var chech = "minato";

// let check1 = 10;
// let check1 = 20;
// console.log(check1);

const pc = "pc";
console.log(pc);

let fun = (arr)=>{
    let tot = 0;
    for(var i=0;i<arr.length;i++){
        tot += arr[i];
    }
    return tot;
}

console.log(fun([1,2,3,4,5]));

//map function

let nums = [1,2,3,4,5];
let compute = nums.map((i)=>i+2);
console.log(compute);

// filter function 
let array = [1,2,3,4,5,6,7];
let even = array.filter(i=>(i%2 == 0));
console.log(even);

// every
let practice1 = array.every(i => i<=5);
console.log(practice1);

//some
let practice2 = array.some(i => i<=5);
console.log(practice2);

let testObj = {name:"jack",age:19};

//destructuring
let {name:moname, age} = testObj;

console.log(testObj.name);
console.log(moname);

// spread operator (or) rest operator

let arr1 = [1,2,3,4,5];
let arr2 = [...arr1, 6,7];
console.log(arr2);


