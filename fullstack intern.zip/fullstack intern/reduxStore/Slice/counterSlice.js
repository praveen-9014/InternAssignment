import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    count: 0,
};

const counterSlice = createSlice({
    name: 'counter',
    initialState,
    reducers: {
        
        increment: (state) => {
            state.count++;
        },
        decrement: (state) => {
            state.count--;
            if(state.count <= 0){
                state.count = 0;
            }
        },
        reset: (state) => {
            state.count = 0;
        },
        inputHandle: (state, action) => {
            // state.count += parseInt(action.payload, 10); 
            state.count += parseInt(document.getElementById('number').value, 10);
        },
    },
});

export const { increment, decrement, reset, inputHandle } = counterSlice.actions;
export default counterSlice.reducer;
