import { configureStore } from "@reduxjs/toolkit";
import counterSlice from "../reduxStore/Slice/counterSlice"

const store=configureStore({
    reducer:{counter:counterSlice}
    // reducer:counterSlice
})

export default store;

