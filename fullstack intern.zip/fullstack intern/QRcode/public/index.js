let link = document.getElementById('link');
let btn = document.getElementById('btn');
let toDisplay = document.getElementById('qrCode');

btn.addEventListener("click", (e) => {
    e.preventDefault();
    getQrcode();
});

// const getQrcode = async () => {
//     let res = await fetch("http://localhost:3000/qr", {
//         method: "POST",
//         headers: {
//             "Content-Type": "application/json"
//         },
//         body: JSON.stringify({ data: link.value }) 
//     });

//     const response = await res.json();
//     console.log(response);

//     let image = document.createElement("img");
//     image.src = response;

//     toDisplay.innerHTML = ""
//     toDisplay.append(image);

// }


const getQrcode = async () => {
    let res = await fetch(`http://localhost:3000/qr?link=${link.value}`);

    const response = await res.json();
    console.log(response);

    let image = document.createElement("img");
    image.src = response;

    toDisplay.innerHTML = ""
    toDisplay.append(image);

}
