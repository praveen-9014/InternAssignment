const { log } = require('console');
const express = require('express');
const path = require('path');
const qrCode = require('qrcode');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res)=>{
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
})

app.get("/qr", async (req, res)=>{
    const data = req.query.link;
    console.log(data);
    let genQr = await qrCode.toDataURL(data);
    res.json(genQr);
    
})

app.post("/qr", async (req, res) => {
    let data = req.body.data;
    console.log(data);
    let genQr = await qrCode.toDataURL(data);
    res.json(genQr);
});

app.listen(3000, ()=>{
    console.log("server is running");
})