// pusre and impure function
// let global = 0;
// let add = (a,b)=> {
//     global++;
//     return a+b
// };

// console.log(add(5,5));

// closure in js

// let closure = ()=>{
//     let temp = {};
//     return (val)=>{
//         if(val in temp){
//             console.log(temp[val]);
//             return temp[val];
//         }
//         let multiple = val*5;
//         temp[val] = multiple
//         return multiple
//     }
// }

// const storage = closure();
// console.log(storage(10));
// console.log(storage(10));

// Local Storage

localStorage.setItem("storage",2500);
localStorage.setItem("storage1","jack");

// assignment 1
let count = localStorage.getItem("count")||0;
localStorage.setItem("count",++count);

console.log(localStorage.getItem("count"))